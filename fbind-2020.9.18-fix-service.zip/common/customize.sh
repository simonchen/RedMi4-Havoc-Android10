##########################################################################################
#
# Magisk Module Custom Script
#
##########################################################################################
##########################################################################################
# Config Flags
##########################################################################################

# Set to true if you do *NOT* want Magisk to mount
# any files for you. Most modules would NOT want
# to set this flag to true
SKIPMOUNT=false

# Set to true if you need to load system.prop
PROPFILE=false

# Set to true if you need post-fs-data script
POSTFSDATA=false

# Set to true if you need late_start service script
LATESTARTSERVICE=true

##########################################################################################
# Replace list
##########################################################################################

# List all directories you want to directly replace in the system
# Check the documentations for more info why you would need this

# Construct your list in the following format
# This is an example
REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here
REPLACE="
"

##########################################################################################
#
# Function Callbacks
#
# The following functions will be called by the installation framework.
# You do not have the ability to modify update-binary, the only way you can customize
# installation is through implementing these functions.
#
# When running your callbacks, the installation framework will make sure the Magisk
# internal busybox path is *PREPENDED* to PATH, so all common commands shall exist.
# Also, it will make sure /data, /system, and /vendor is properly mounted.
#
##########################################################################################
##########################################################################################
#
# The installation framework will export some variables and functions.
# You should use these variables and functions for installation.
#
# ! DO NOT use any Magisk internal paths as those are NOT public API.
# ! DO NOT use other functions in util_functions.sh as they are NOT public API.
# ! Non public APIs are not guranteed to maintain compatibility between releases.
#
# Available variables:
#
# MAGISK_VER (string): the version string of current installed Magisk
# MAGISK_VER_CODE (int): the version code of current installed Magisk
# BOOTMODE (bool): true if the module is currently installing in Magisk Manager
# MODPATH (path): the path where your module files should be installed
# TMPDIR (path): a place where you can temporarily store files
# ZIPFILE (path): your module's installation zip
# ARCH (string): the architecture of the device. Value is either arm, arm64, x86, or x64
# IS64BIT (bool): true if $ARCH is either arm64 or x64
# API (int): the API level (Android version) of the device
#
# Availible functions:
#
# ui_print <msg>
#     print <msg> to console
#     Avoid using 'echo' as it will not display in custom recovery's console
#
# abort <msg>
#     print error message <msg> to console and terminate installation
#     Avoid using 'exit' as it will skip the termination cleanup steps
#
# set_perm <target> <owner> <group> <permission> [context]
#     if [context] is empty, it will default to "u:object_r:system_file:s0"
#     this function is a shorthand for the following commands
#       chown owner.group target
#       chmod permission target
#       chcon context target
#
# set_perm_recursive <directory> <owner> <group> <dirpermission> <filepermission> [context]
#     if [context] is empty, it will default to "u:object_r:system_file:s0"
#     for all files in <directory>, it will call:
#       set_perm file owner group filepermission context
#     for all directories in <directory> (including itself), it will call:
#       set_perm dir owner group dirpermission context
#
##########################################################################################
##########################################################################################
# If you need boot scripts, DO NOT use general boot scripts (post-fs-data.d/service.d)
# ONLY use module scripts as it respects the module status (remove/disable) and is
# guaranteed to maintain the same behavior in future Magisk releases.
# Enable boot scripts by setting the flags in the config section above.
##########################################################################################

# Set what you want to display when installing your module

print_modname() {
  ui_print " "
  ui_print "$(i name | sed 's/ (.*//') $(i version)"
  ui_print "$(i author)"
  ui_print " "
}

set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH 0 0 0755 0644

  # Here are some examples:
  # set_perm_recursive  $MODPATH/system/lib       0     0       0755      0644
  # set_perm  $MODPATH/system/bin/app_process32   0     2000    0755      u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0     2000    0755      u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0     0       0644

  # Permissions for executables
  for f in $MODPATH/bin/* $MODPATH/system/*bin/* $MODPATH/*.sh; do
    [ -f "$f" ] && set_perm $f 0 0 0755
  done
}

debug_exit() {
  local exitCode=$?
  echo -e "\n***EXIT $exitCode***\n"
  set +euxo pipefail
  set
  echo
  echo "SELinux status: $(getenforce 2>/dev/null || sestatus 2>/dev/null)" \
    | sed 's/En/en/;s/Pe/pe/'
  if [ $e -ne 0 ]; then
    $BOOTMODE || recovery_cleanup
    set -u
    rm -rf $TMPDIR
  fi 1>/dev/null 2>&1
  echo
  exit $exitCode
} 1>&2

# module.prop reader
i() {
  local p=$MODPATH/module.prop
  grep_prop $1 $p
}

get_cpu_arch() {
  case $(uname -m) in
    *86*) echo -n x86;;
    *ar*) echo -n arm;;
    *) ui_print " "
       ui_print "(!) Unsupported CPU architecture ($ARCH)"
       ui_print " "
       exit 1;;
  esac
}

version_info() {
  local line=""
  local println=false

  # a note on untested Magisk versions
  if [ ${MAGISK_VER/.} -gt 180 ]; then
    ui_print " "
    ui_print "  (i) NOTE: this Magisk version hasn't been tested by @VR25!"
    ui_print "    - If you come across any issue, please report."
  fi

  ui_print " "
  ui_print "  WHAT'S NEW"
  cat ${config%/*}/info/README.md | while read line; do
    echo "$line" | grep -q '\*\*.*\(.*\)\*\*' && println=true
    $println && echo "$line" | grep -q '^$' && break
    $println && echo "    $line" | grep -v '\*\*.*\(.*\)\*\*'
  done
  ui_print " "

  ui_print "  LINKS"
  ui_print "    - Facebook page: facebook.com/VR25-at-xda-developers-258150974794782/"
  ui_print "    - Git repository: github.com/Magisk-Modules-Repo/fbind/"
  ui_print "    - Telegram channel: t.me/vr25_xda/"
  ui_print "    - Telegram profile: t.me/vr25xda/"
  ui_print "    - XDA thread: forum.xda-developers.com/apps/magisk/module-magic-folder-binder-t3621814/"
  ui_print " "
}

cleanup() {
  # migrate data
  {
    mv /data/media/fbind /data/adb/ \
      || mv /data/media/0/fbind /data/adb/
    rm -rf /data/media/0/fbind
    mv /data/media/0/fbind_config_backup.txt \
      /data/media/0/.fbind_config_backup.txt
  } 2>/dev/null

  # patch config & remove obsolete data
  # restore config
  [ -e $config ] || cp -af /data/media/0/.fbind_config_backup.txt $config 2>/dev/null

  # backup
  [ $curVer -lt 201812140 ] && [ -e $config ] \
    && cp -f $config ${config/./_backup.}

  if [ $curVer -lt 201812030 ]; then

    cd /data/property/

    # remove obsolete files
    rm -rf *esdfs_sdcard *fuse_sdcard *sys.sdcardfs \
      ${config%/*}/logs/ /storage/*/.fbind_bkp/ /external_sd/.fbind_bkp/ \
      /sbin/.magisk/modules/.core/*/fbind.sh ${config%/*}/*tmp* 2>/dev/null

    if   [ -e $config ]; then
      # remove filesystem arguments
      sed -i '/^part .*/s/ f2fs//g; /s/ ext.//g; \
        /s/ fat32//g; /s/ vfat//g; /s/ exfat//g; /s/ fat//g' $config

      # remove <setenforce x> lines
      sed -i '/^setenforce/d' $config

      # remove fsck lines
      sed -i '/^fsck/d; /^e2fsck/d' $config

      # rename "cleanup " to "remove "
      sed -i 's/^cleanup /remove /g' $config

      # rename bind_mnt to bind_mount
      sed -i 's/^bind_mnt /bind_mount /g' $config

      # rename LOOP to loop
      sed -i 's/^LOOP /loop /g' $config
    fi
  fi

  # remove obsolete config backups
  [ $curVer -lt 201812040 ] && rm $config.2018* 2>/dev/null
}

set -euxo pipefail
trap debug_exit EXIT

binArch=$(get_cpu_arch)
config=/data/adb/$MODID/config.txt
curVer=$(grep_prop versionCode $MODPATH/module.prop || :)
[ -z "$curVer" ] && curVer=0

if [ $curVer -eq $(i versionCode) ] && ! $BOOTMODE; then
  touch $MODPATH/disable
  ui_print " "
  ui_print "(i) Module disabled"
  ui_print " "
  set +euo pipefail
  $BOOTMODE || recovery_cleanup
  set -u
  exit 0
fi
cd $MODPATH/bin
ln -s cryptsetup_$binArch cryptsetup
ln -s fstype_$binArch fstype

# force FUSE
if [ -e $MODPATH/system.prop ] || [ -e /data/forcefuse ] \
  || echo "${0##*/}" | grep -iq fuse || $PROPFILE
then
  mv $MODPATH/FUSE.prop $MODPATH/system.prop
  rm -rf /data/forcefuse 2>/dev/null || :
fi

set +euo pipefail

set_permissions
cleanup

