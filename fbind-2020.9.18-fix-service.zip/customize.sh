#!/bin/bash
ui_print "Android 10+ Enter in customized installation"
ui_print "The module has been extracted at: $MODPATH"

install_system() {

  binArch=${ARCH//[0-9]/}
  ui_print "$binArch"
  config=/data/adb/$MODID/config.txt

  set_perm_custom() {
    chown 0:0 "$@"
    chmod 0755 "$@"
  }

  # https://github.com/topjohnwu/magisk_files/blob/2d7ddefbe4946806de1875a18247b724f5e7d4a0/notes.md
  # Android 10+ /system is no longer a valid mount point. For existing root apps that remounts /system to rw, you will have to remount / instead of /system
  ui_print "Remount /sbin/.magisk/mirror/system_root for read and write access."
  mount -o rw,remount /

  # install/uninstall
    ui_print "(i) Uninstalling old version if had one"
    rm -rf /system/etc/init.d/$MODID \
           /system/etc/init/$MODID.rc \
           /system/etc/$MODID \
           /system/addon.d/$MODID.sh \
           /system/bin/$MODID* \
           /system/xbin/$MODID* 2>/dev/null || :
    ui_print " "

    ui_print "(i) Installing"

    # place files
    mv $MODPATH/common/sample* /data/adb/$MODID/
    mv $MODPATH/bin/cryptsetup_$binArch $MODPATH/bin/cryptsetup
    mv $MODPATH/bin/fstype_$binArch $MODPATH/bin/fstype
    mv -f $MODPATH/common/$MODID* /system/bin/
    mv -f $MODPATH/init/$MODID.rc /system/etc/init/$MODID.rc
    mv -f $MODPATH/common/core.sh $MODPATH/
    set_perm_custom /system/*bin/$MODID* $MODPATH/bin/cryptsetup $MODPATH/bin/fstype

}

# Do it!
install_system